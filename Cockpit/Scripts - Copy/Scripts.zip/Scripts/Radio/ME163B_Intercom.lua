GUI = {
	interphone = {
		interphone = true,
		displayName = "Interphone"
	}
}

need_to_be_closed = true